import UIKit

enum typeofcar: String {
    case car = "tesla"
    case engine = "electric"
    case wheel = "turbine wheel"
    case color = "black"
}

class Descriptionofcar{
    var wheel: Int = 4
    var engine: Int = 4
    var car1: Int = 1
    
    func invintory (wheel: Int,engine: Int, car1: Int)-> Int{
        return wheel + engine + car1
    }
}
var total1 = Descriptionofcar()
var shoppingcart = total1.invintory
